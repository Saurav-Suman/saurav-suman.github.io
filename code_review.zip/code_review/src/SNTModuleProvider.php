<?php

namespace Tps\SNTModule;


use Tps\Contracts\Core\Http\ClientInterface;
use Tps\Contracts\Core\ModuleBuilderInterface;
use Tps\Contracts\Core\ModuleContainerInterface;
use Tps\Contracts\Core\TimerInterface;
use Tps\Contracts\Module\ModuleProviderInterface;
use Tps\SNTModule\Client\ClientConfiguration;
use Tps\SNTModule\Exception\HttpExceptionHandler;
use Tps\SNTModule\Handler\PackageCreationHandler;
use Tps\SNTModule\RequestBuilder\PickupRequestBuilder;
use Tps\SNTModule\Handler\PackageStatusUpdateHandler;

/**
 * Class SNTModuleProvider
 *
 *
 */
class SNTModuleProvider implements ModuleProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function registerHandlers(ModuleBuilderInterface $builder)
    {
        $builder
            ->registerPackageCreationHandler(
                function (ModuleContainerInterface $container, array $config) {
                    $clientConfig = new ClientConfiguration(
                        $config['pickup_endpoint'],
                        $config['token'],
                        $config['fixed_timestamp'],
                        $config['source_id']
                    );

                    return new PackageCreationHandler(
                        $container->get(ClientInterface::class),
                        new PickupRequestBuilder(
                            $container->get(TimerInterface::class),
                            $config['timezone'],
                            $clientConfig
                        ),
                        new HttpExceptionHandler($config['retry_config'])
                    );
                }
            );

        $builder->registerPackageStatusUpdateHandler(
            function (ModuleContainerInterface $container, array $config) {
                return new PackageStatusUpdateHandler(
                    $config['status_mapping'],
                    $config['reason_code_mapping']
                );
            }
        );

    }

    /**
     * {@inheritdoc}
     */
    public function getModuleName(): string
    {
        return 'snt';
    }
}
