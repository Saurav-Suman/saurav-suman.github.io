<?php

declare(strict_types = 1);

namespace Tps\SNTModule\Handler;

use DateTime;
use DateTimeZone;
use Tps\Contracts\Core\Processor\PackageStatusUpdateProcessorInterface;
use Tps\Contracts\Module\Handler\PackageStatusUpdateHandlerInterface;
use Tps\Contracts\Module\Request\PackageStatusUpdateRequestInterface;
use Tps\SNTModule\Request\PackageStatusUpdateRequest;
use Tps\Contracts\Module\Exception\ValidationException;

/**
 * Update package status handler
 */
class PackageStatusUpdateHandler implements PackageStatusUpdateHandlerInterface
{

    /**
     * @var array
     */
    protected $reasonCodeMap;

    /**
     * @var array
     */
    protected $statusCodeMap;

    /**
     * PackageStatusUpdateHandler constructor.
     *
     * @param array $statusCode
     * @param array $reasonCode
     */
    public function __construct(
        $statusCode,
        $reasonCode
    ) {
        $this->statusCodeMap = $statusCode;
        $this->reasonCodeMap = $reasonCode;

    }

    /**
     * {@inheritdoc}
     *
     * @throws \InvalidArgumentException
     */
    public function createRequestObject(array $payload): PackageStatusUpdateRequestInterface
    {
        list($trackingNumber, $tplStatus, $dateTime, $reasonCode, $packageStatusLzd, $reasonCodeLzd) = $this->validatePayload(
            $payload
        );

        return new PackageStatusUpdateRequest(
            $trackingNumber,
            $tplStatus,
            $dateTime,
            $reasonCode,
            $packageStatusLzd,
            $reasonCodeLzd
        );
    }

    /**
     * Validate payload and return parsed data.
     *
     * @param array $payload
     *
     * @throws ValidationException
     * @return array
     */
    private function validatePayload(array $payload): array
    {
        if (empty($payload['trackingno'])) {
            throw new ValidationException('trackingno', 'Missing "trackingno" parameter.');
        }

        if (empty($payload['statuscode'])) {
            throw new ValidationException('statuscode', 'Missing "statuscode" parameter.');
        }

        $timeZone = new \DateTimeZone('Asia/Kuala_Lumpur');

        $dateTime = $payload['dateTime'] ?? null;
        if (empty($dateTime)) {
            throw new ValidationException('dateTime', 'Missing "dateTime" parameter.');
        }
        $dateTime = \DateTime::createFromFormat(
            'Y-m-d H:i:s',
            $dateTime,
            $timeZone
        );

        $lastErrors = \DateTime::getLastErrors();
        if (0 < $lastErrors['warning_count'] || 0 < $lastErrors['error_count']) {
            throw new ValidationException(
                'datetime',
                sprintf('Value "%s" of "dateTime" parameter is not in Y-m-d H:i:s format.', $payload['dateTime'])
            );
        }


        $tplReasonCode = trim($payload['failedreasonCode']);

        $reasonCodeLzd = array_key_exists($tplReasonCode, $this->reasonCodeMap) ?
            $this->reasonCodeMap[$tplReasonCode] : "";


        $packageStatusLzd = array_key_exists(trim($payload['statuscode']), $this->statusCodeMap) ?
            $this->statusCodeMap[trim($payload['statuscode'])] : "";

        return [
            $payload['trackingno'],
            trim($payload['statuscode']),
            $dateTime,
            $tplReasonCode,
            $packageStatusLzd,
            $reasonCodeLzd,
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function handle(PackageStatusUpdateProcessorInterface $processor)
    {
        $processor->doAccept();
    }
}
