<?php

namespace Tps\SNTModule\Handler;

use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;
use Tps\Contracts\Core\Http\ClientInterface;
use Tps\Contracts\Core\Http\Exception\HttpException;
use Tps\Contracts\Core\Processor\PackageCreationProcessorInterface;
use Tps\Contracts\Module\Handler\PackageCreationHandlerInterface;
use Tps\SNTModule\Exception\HttpExceptionHandler;
use Tps\SNTModule\Exception\PickupRequestRejectedException;
use Tps\SNTModule\RequestBuilder\PickupRequestBuilder;

/**
 * Package creation handler for SNT
 */
class PackageCreationHandler implements PackageCreationHandlerInterface
{
    const SUCCESS_STATUS = 200;

    /**
     * @var ClientInterface
     */
    private $client;

    /**
     * @var HttpExceptionHandler
     */
    private $exceptionHandler;

    /**
     * @var PickupRequestBuilder
     */
    private $requestBuilder;

    /**
     * PackageCreationHandler constructor.
     *
     * @param ClientInterface      $client
     * @param PickupRequestBuilder $requestBuilder
     * @param HttpExceptionHandler $exceptionHandler
     */
    public function __construct(
        ClientInterface $client,
        PickupRequestBuilder $requestBuilder,
        HttpExceptionHandler $exceptionHandler
    ) {
        $this->client           = $client;
        $this->exceptionHandler = $exceptionHandler;
        $this->requestBuilder   = $requestBuilder;
    }

    /**
     * {@inheritdoc}
     */
    public function handle(PackageCreationProcessorInterface $processor)
    {
        $pickupRequest = $this->requestBuilder->buildRequest($processor->getContext()->getPackageCreationRequest());

        try {
            $response = $this->client->send($pickupRequest);
            $this->parseResponse($pickupRequest, $response);
            $processor->doAccept();
        } catch (HttpException $exception) {
            $this->exceptionHandler->handle($exception, $processor);
        }
    }

    /**
     * @param RequestInterface  $request
     * @param ResponseInterface $response
     *
     * @throws PickupRequestRejectedException
     */
    private function parseResponse(RequestInterface $request, ResponseInterface $response)
    {
        $body = json_decode((string) $response->getBody(), true);

        if (JSON_ERROR_NONE !== json_last_error()) {
            throw new PickupRequestRejectedException('Response is not in json format.', $request, $response);
        }


        if ((int) $body['Code'] !== self::SUCCESS_STATUS) {
            throw new PickupRequestRejectedException(
                'Response is not returned success status.',
                $request,
                $response
            );
        }
    }
}
