<?php
declare(strict_types = 1);

namespace Tps\SNTModule\Client;

class ClientConfiguration
{
    /**
     * @var string
     */
    private $pickupEndpoint;


    /**
     * @var string
     */
    private $token;

    /**
     * @var string
     */
    private $fixTime;

    /**
     * @var string
     */
    private $sourceId;


    /**
     *
     * @param string $pickupEndpoint
     * @param string $token
     * @param string $fixTime
     * @param string $sourceId
     */
    public function __construct(
        string $pickupEndpoint,
        string $token,
        string $fixTime,
        string $sourceId


    ) {
        $this->pickupEndpoint = $pickupEndpoint;
        $this->token          = $token;
        $this->fixTime        = $fixTime;
        $this->sourceId       = $sourceId;


    }

    /**
     * Get Client Pickup API Endpoint
     *
     * @return string
     */
    public function getPickupApiEndpoint(): string
    {
        return $this->pickupEndpoint;
    }


    /**
     * Get Token
     *
     * @return string
     */
    public function getToken(): string
    {
        return $this->token;
    }

    /**
     * Get Token
     *
     * @return string
     */
    public function getFixTime(): string
    {
        return $this->fixTime;
    }

    /**
     * Get Token
     *
     * @return string
     */
    public function getSourceId(): string
    {
        return $this->sourceId;
    }

}
