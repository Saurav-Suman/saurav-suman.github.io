<?php

namespace Tps\SNTModule\Exception;

use Tps\Contracts\Core\Http\Exception\ConnectException;
use Tps\Contracts\Core\Http\Exception\HttpException;
use Tps\Contracts\Core\Http\Exception\ServerException;
use Tps\Contracts\Core\Processor\PackageCreationProcessorInterface;


/**
 * Handle exception thrown from HTTP client
 */
class HttpExceptionHandler
{
    /**
     * @var array
     */
    private $retryConfig;

    /**
     * HttpExceptionHandler constructor.
     *
     * @param array $retryConfig Array of pairs: 1 => 60, 2 => 120, 3 => 300, the unit is seconds.
     */
    public function __construct(array $retryConfig)
    {
        $this->retryConfig = $retryConfig;
    }

    /**
     * @param HttpException                     $exception
     * @param PackageCreationProcessorInterface $processor
     */
    public function handle(HttpException $exception, PackageCreationProcessorInterface $processor)
    {
        if ($exception instanceof ConnectException || $exception instanceof ServerException) {
            $this->retryOrFail($processor, $exception);
        } else {
            $processor->doReject($exception);
        }
    }

    /**
     * @param PackageCreationProcessorInterface $processor
     * @param HttpException                     $exception
     *
     * @SuppressWarnings(PHPMD.ElseExpressions)
     */
    protected function retryOrFail(PackageCreationProcessorInterface $processor, HttpException $exception)
    {
        $nextRetry = $processor->getAttempts() + 1;

        if (array_key_exists($nextRetry, $this->retryConfig)) {
            $processor->doRetry($this->retryConfig[$nextRetry], $exception);
        } else {
            $processor->doReject(
                new RetryExceededException(
                    sprintf(
                        "Failed due to exceed of {$nextRetry} retries, with error: %s.",
                        $exception->getMessage()
                    ),
                    0,
                    $exception
                )
            );
            //$processor->doReject(new \Exception("Failed due to exceed {$nextRetry} times of attempts.", 0, $exception));
        }
    }
}
