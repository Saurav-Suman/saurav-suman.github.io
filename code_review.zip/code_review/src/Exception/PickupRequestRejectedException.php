<?php

declare(strict_types = 1);

namespace Tps\SNTModule\Exception;

use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;
use Tps\Contracts\Core\Http\Exception\ClientException;

/**
 * Thrown when response of pickup request is not returned success code.
 */
class PickupRequestRejectedException extends \RuntimeException implements ClientException
{
    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var ResponseInterface
     */
    private $response;

    /**
     * PickupRequestRejectedException constructor.
     *
     * @param string            $message
     * @param RequestInterface  $request
     * @param ResponseInterface $response
     * @param int               $code
     * @param \Exception|null   $previous
     */
    public function __construct(
        string $message,
        RequestInterface $request,
        ResponseInterface $response,
        int $code = 0,
        \Exception $previous = null
    ) {
        parent::__construct($message, $code, $previous);

        $this->request  = $request;
        $this->response = $response;
    }

    /**
     * Return response.
     *
     * @return ResponseInterface
     */
    public function getResponse(): ResponseInterface
    {
        return $this->response;
    }

    /**
     * Return request.
     *
     * @return RequestInterface
     */
    public function getRequest(): RequestInterface
    {
        return $this->request;
    }
}
