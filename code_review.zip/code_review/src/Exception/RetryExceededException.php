<?php

namespace Tps\SNTModule\Exception;

use Tps\Contracts\Module\Exception\ModuleExceptionInterface;

/**
 * Thrown when number of retries is exceeded.
 */
class RetryExceededException extends \RuntimeException implements ModuleExceptionInterface
{
}