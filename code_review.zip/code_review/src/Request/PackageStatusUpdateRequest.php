<?php
declare (strict_types = 1);

namespace Tps\SNTModule\Request;

use Tps\Contracts\Module\Request\PackageStatusUpdateRequestInterface;
use Tps\Contracts\Module\Request\TplReasonCodeAwareRequestInterface;

/**
 * Class PackageStatusUpdateRequest
 *
 * @package Tps\SNTModule\Request
 */
class PackageStatusUpdateRequest implements PackageStatusUpdateRequestInterface, TplReasonCodeAwareRequestInterface
{

    /**
     * @var string
     */
    private $trackingNumber;

    /**
     * @var string
     */
    private $tplStatus;

    /**
     * @var \DateTime
     */
    private $datetime;

    /**
     * @var string
     */
    private $reasonCode;

    /**
     * @var string
     */
    private $packageStatusLzd;

    /**
     * @var string
     */
    private $reasonCodeLzd;


    /**
     * PackageStatusUpdateRequest constructor
     *
     * @param string    $trackingNumber
     * @param string    $tplStatus
     * @param \DateTime $datetime
     * @param string    $reasonCode
     * @param string    $packageStatusLzd
     * @param string    $reasonCodeLzd
     */
    public function __construct(
        string $trackingNumber,
        string $tplStatus,
        \DateTime $datetime,
        string $reasonCode,
        string $packageStatusLzd,
        string $reasonCodeLzd
    ) {
        $this->trackingNumber   = $trackingNumber;
        $this->tplStatus        = $tplStatus;
        $this->datetime         = $datetime;
        $this->reasonCode       = $reasonCode;
        $this->packageStatusLzd = $packageStatusLzd;
        $this->reasonCodeLzd    = $reasonCodeLzd;
    }

    /**
     * {@inheritdoc}
     */
    public function getTrackingNumber(): string
    {
        return $this->trackingNumber;
    }

    /**
     * {@inheritdoc}
     */
    public function getPackageStatus(): string
    {
        return $this->packageStatusLzd;
    }

    /**
     * {@inheritdoc}
     */
    public function getTplStatus(): string
    {
        return $this->tplStatus;
    }

    /**
     * @return string
     */
    public function getTplReasonCode(): string
    {
        return $this->reasonCode;
    }

    /**
     * {@inheritdoc}
     */
    public function getReasonCode(): string
    {
        return $this->reasonCodeLzd;
    }

    /**
     * {@inheritdoc}
     */
    public function getLocation(): string
    {
        return '';
    }

    /**
     * {@inheritdoc}
     */
    public function getDateTime()
    {
        return $this->datetime;
    }

    /**
     * {@inheritdoc}
     */
    public function getLongitudeLocation()
    {
        return null;
    }

    /**
     * {@inheritdoc}
     */
    public function getLatitudeLocation()
    {
        return null;
    }
}
