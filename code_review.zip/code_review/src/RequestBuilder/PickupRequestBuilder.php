<?php
declare(strict_types = 1);

namespace Tps\SNTModule\RequestBuilder;

use Psr\Http\Message\RequestInterface;
use Tps\Contracts\Core\PackageCreationRequestInterface;
use Tps\Contracts\Core\PackageItemInterface;
use Tps\Contracts\Core\TimerInterface;
use Tps\SNTModule\Client\ClientConfiguration;

/**
 * Builder to build pickup request to SNT
 */
class PickupRequestBuilder
{
    const PAYMENT_TYPE = 'Prepaid';
    const SlUG         = 'snt';
    const CURRENCY     = "MYR";
    const CLIENT_ID    = 35597;
    const CLIENT_TYPE  = 'B';

    /**
     * @var TimerInterface
     */
    private $timer;


    /**
     * @var \DateTimeZone
     */
    private $timezone;

    /**
     * @var  ClientConfiguration
     */
    private $config;

    /**
     * PickupRequestBuilder constructor.
     *
     * @param TimerInterface       $timer
     * @param \DateTimeZone        $timezone
     * @param  ClientConfiguration $config
     */
    public function __construct(
        TimerInterface $timer,
        \DateTimeZone $timezone,
        ClientConfiguration $config
    ) {
        $this->timer    = $timer;
        $this->timezone = $timezone;
        $this->config   = $config;
    }

    /**
     * @param PackageCreationRequestInterface $request
     *
     * @return RequestInterface
     */
    public function buildRequest(PackageCreationRequestInterface $request): RequestInterface
    {

        $customer             = $request->getCustomer();
        $shipper              = $request->getShipper();
        $packageItem          = $request->getItems();
        $itemDescriptionArray = [];
        $itemTotalWeight      = 0;


        array_push(
            $itemDescriptionArray,
            array_map(
                function (PackageItemInterface $packageItemData) {

                    return [
                        "desc"   => $packageItemData->getName(),
                        "qty"    => $packageItemData->getQuantity(),
                        "weight" => $packageItemData->getWeight(),
                        "width"  => '',
                        "height" => '',
                        "depth"  => '',

                    ];
                },
                $packageItem
            )
        );
        $itemDescriptionArray[0] = array_values($itemDescriptionArray[0]);

        foreach ($packageItem as $key => $item) {

            $itemTotalWeight += $item->getWeight();
        }


        $platformCreationTime = $request->getPlatformCreationTime();
        $orderDate            = $platformCreationTime instanceof \DateTime ? $platformCreationTime->setTimezone(
            $this->timezone
        ) : $this->timer->getNow(
            $this->timezone
        );
        $formattedOrderDate   = $orderDate->format('d.m.Y H:i:s');

        $payloads = [
            'OrderNo'            => $request->getPackage()->getTrackingNumber(),
            'ExtOrderId'         => $request->getPackage()->getPlatformPackageId(),
            'ExtOrderNo'         => $request->getPackage()->getPackageUuid(),
            'ExtOrderDate'       => $formattedOrderDate,
            'ClientID'           => self::CLIENT_ID,
            'ClientType'         => self::CLIENT_TYPE,
            'ClientName'         => $shipper->getName(),
            'PickUpAttnTo'       => $shipper->getSenderName(),
            'PickUpAddr1'        => $shipper->getAddress()->getDetails(),
            'PickUpAddr2'        => '',
            'PickUpPostCode'     => $shipper->getAddress()->getZipCode(),
            'PickUpCity'         => $shipper->getAddress()->getCity(),
            'PickUpState'        => $shipper->getAddress()->getProvince(),
            'PickUpPhone'        => $shipper->getMobile(),
            'PickUpEmail'        => $shipper->getContactEmail(),
            'DeliverToAttnTo'    => $customer->getName(),
            'DeliverToAddr1'     => $customer->getAddress()->getDetails(),
            'DeliverToAddr2'     => '',
            'DeliverToPostCode'  => $customer->getAddress()->getZipCode(),
            'DeliverToCity'      => $customer->getAddress()->getCity(),
            'DeliverToState'     => $customer->getAddress()->getProvince(),
            'DeliverToPhone'     => $customer->getMobile(),
            'DeliverToEmail'     => $customer->getEmail(),
            'TotalWeight'        => $itemTotalWeight,
            'TotalVolume'        => $request->getVolume(),
            'PaymentType'        => self::PAYMENT_TYPE,
            'TotalPrice'         => $request->getTotalPrice(),
            'TotalPriceCurrency' => self::CURRENCY,
            'Parcels'            => $itemDescriptionArray[0],
            'SourceID'           => $this->config->getSourceId(),
            'TimeStamp'          => $this->config->getFixTime(),
            'Token'              => $this->config->getToken(),
        ];


        return new \GuzzleHttp\Psr7\Request(
            'POST',
            $this->config->getPickupApiEndpoint(),
            ['Content-Type' => 'application/json'],
            json_encode($payloads)
        );
    }


}
