# Tps/SNTModule
==========

### Installation

```
composer require lazada/tps-snt-module ^1.0
```



```

## Tests
```sh
./vendor/phpunit/phpunit/phpunit
```
See test result at `./build`
