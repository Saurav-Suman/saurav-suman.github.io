<?php


declare(strict_types = 1);

use Tps\Contracts\Core\Model\Workflow;
use Tps\Contracts\Core\PackageStatusInterface as PSI;

return [
    Workflow::PACKAGE_CREATION => [
        'default' => [
            'pickup_endpoint' => 'api_url', //ENV
            'source_id'       => 'LAZADA_3PL',//ENV
            'fixed_timestamp' => '20170804162014',
            'token'           => 'token',
            'retry_config'    => [
                1 => 60,
                2 => 120,
                3 => 500,
            ],

            'timezone' => new \DateTimeZone('Asia/Kuala_Lumpur'),
        ],

    ],


    Workflow::PACKAGE_STATUS_UPDATE => [
        'default' => [
            'status_mapping'      => [
                'U'  => PSI::DOMESTIC_PICKUP_SIGN_IN_SUCCESS,
                'A'  => PSI::DOMESTIC_SC_SIGN_IN_SUCCESS,
                'O'  => PSI::DOMESTIC_OB_SUCCESS_IN_SORT_CENTER,
                'I'  => PSI::DOMESTIC_OUT_FOR_DELIVERY,
                'F1' => PSI::DOMESTIC_1ST_ATTEMPT_FAILED,
                'T1' => PSI::DOMESTIC_REDELIVERY,
                'D'  => PSI::DOMESTIC_DELIVERED,
                'F3' => PSI::DOMESTIC_DELIVERY_FAILED,
                'N'  => PSI::DOMESTIC_PACKAGE_RETURNED,

            ],
            'reason_code_mapping' => [
                'A1' => 'Incomplete address',
                'A2' => 'Customer not at home',

            ],
        ],
    ],
];