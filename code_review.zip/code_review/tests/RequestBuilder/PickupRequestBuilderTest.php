<?php
declare(strict_types = 1);

namespace Tests\Tps\SNTModule\RequestBuilder;

use Psr\Http\Message\RequestInterface;
use Tps\Contracts\Core\TimerInterface;
use Tps\Contracts\Stubs\PackageCreationRequestMockBuilder;
use Tps\SNTModule\RequestBuilder\PickupRequestBuilder;
use Tps\SNTModule\Client\ClientConfiguration;

/**
 * @covers \Tps\SNTModule\RequestBuilder\PickupRequestBuilder
 */
class PickupRequestBuilderTest extends \PHPUnit_Framework_TestCase
{

    /**
     * @var TimerInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $timerMock;

    /**
     * @var clientConfig
     */
    private $clientConfig;

    /**
     * @var PickupRequestBuilder
     */
    private $pickupRequestBuilder;

    /**
     * @var array
     */
    private $packageData;


    /**
     * @var string
     */
    private $endpoint;

    /**
     * @var string
     */
    private $token;

    /**
     * @var string
     */
    private $fixTime;

    /**
     * @var string
     */
    private $sourceId;


    /**
     * Test buildRequest()
     *
     * @param array $packageData
     *
     * @dataProvider packageDataProvider
     */
    public function testBuildRequest($packageData, $expected)
    {


        $this->clientConfig = new ClientConfiguration(
            $this->endpoint,
            $this->token,
            $this->fixTime,
            $this->sourceId
        );

        $this->pickupRequestBuilder = new PickupRequestBuilder(
            $this->timerMock,
            new \DateTimeZone('Asia/Kuala_Lumpur'),
            $this->clientConfig
        );


        $this->packageData  = $packageData;
        $pkgCreationRequest = PackageCreationRequestMockBuilder::build($this, $this->packageData);

        $request = $this->pickupRequestBuilder->buildRequest($pkgCreationRequest);

        static::assertInstanceOf(RequestInterface::class, $request);
        static::assertEquals('POST', $request->getMethod());
        static::assertEquals($this->endpoint, (string) $request->getUri());
        static::assertArraySubset(
            ['Content-Type' => ['application/json']],
            $request->getHeaders()
        );
        static::assertEquals(json_encode($expected), $request->getBody()->__toString());

    }

    /**
     * @see \Tps\SNTModule\RequestBuilder\PickupRequestBuilder::buildRequest
     */
    public function testBuildRequestWithNonPlatformCreationTime()
    {


        $this->clientConfig = new ClientConfiguration(
            $this->endpoint,
            $this->token,
            $this->fixTime,
            $this->sourceId
        );

        $this->pickupRequestBuilder = new PickupRequestBuilder(
            $this->timerMock,
            new \DateTimeZone('Asia/Kuala_Lumpur'),
            $this->clientConfig
        );

        $timezone    = new \DateTimeZone('Asia/Kuala_Lumpur');
        $testCase    = $this->packageDataProvider()['AllDataSnt'];
        $packageData = $testCase['values'];
        $expected    = $testCase['expected'];


        //print_r($expected);


        //$packageData['shipper']              = [];
        $packageData['platformCreationTime'] = null;
        $now                                 = new \DateTime('2017-02-10 10:10:10', $timezone);
        $expected['ExtOrderDate']            = '10.02.2017 10:10:10';
        $this->timerMock->expects(static::once())
            ->method('getNow')
            ->with($timezone)
            ->willReturn($now);


        $pkgCreationRequest = PackageCreationRequestMockBuilder::build($this, $packageData);

        $request = $this->pickupRequestBuilder->buildRequest($pkgCreationRequest);

        static::assertInstanceOf(RequestInterface::class, $request);
        static::assertEquals('POST', $request->getMethod());
        static::assertEquals($this->endpoint, (string) $request->getUri());
        static::assertArraySubset(
            ['Content-Type' => ['application/json']],
            $request->getHeaders()
        );
        static::assertEquals(json_encode($expected), $request->getBody()->__toString());
    }

    /**
     * @return array
     */
    public function packageDataProvider()
    {
        return [
            'AllDataSnt' => [
                'values'   => [
                    'customer'             => [
                        'name'    => 'Customer\'s Name',
                        'mobile'  => '8505885570',
                        'email'   => 'abc@abc.com',
                        'address' => [
                            'province' => 'KL',
                            'details'  => 'Nothing to add',

                            'city'    => 'KL',
                            'zipCode' => '50000',

                        ],
                    ],
                    'shipper'              => [
                        'name'         => 'SNT',
                        'mobile'       => '0123456789',
                        'contactEmail' => 'abc@abc.com',
                        'address'      => [
                            'province' => 'KL',
                            'details'  => 'Nothing to add',
                            'zipCode'  => '50000',

                        ],
                    ],
                    'package'              => [
                        'trackingNumber'    => 'TRACK-123',
                        'platformPackageId' => 'TRACK-123',
                        'packageUuid'       => 'uuid',
                    ],
                    'items'                => [
                        ['name' => 'iPhone 7', 'quantity' => '1', 'weight' => 10],
                        ['name' => 'iPhone 8', 'quantity' => '2', 'weight' => 20],

                    ],
                    'totalPrice'           => 200.0,
                    'volume'               => 2.0,
                    'platformCreationTime' => new \DateTime(
                        '2018-03-14 08:00:00',
                        new \DateTimeZone('Asia/Kuala_Lumpur')
                    ),

                ],
                'expected' => [
                    'OrderNo'            => 'TRACK-123',
                    'ExtOrderId'         => 'TRACK-123',
                    'ExtOrderNo'         => 'uuid',
                    'ExtOrderDate'       => '14.03.2018 08:00:00',
                    'ClientID'           => 35597,
                    'ClientType'         => 'B',
                    'ClientName'         => 'SNT',
                    'PickUpAttnTo'       => '',
                    'PickUpAddr1'        => 'Nothing to add',
                    'PickUpAddr2'        => '',
                    'PickUpPostCode'     => '50000',
                    'PickUpCity'         => '',
                    'PickUpState'        => 'KL',
                    'PickUpPhone'        => '0123456789',
                    'PickUpEmail'        => 'abc@abc.com',
                    'DeliverToAttnTo'    => 'Customer\'s Name',
                    'DeliverToAddr1'     => 'Nothing to add',
                    'DeliverToAddr2'     => '',
                    'DeliverToPostCode'  => '50000',
                    'DeliverToCity'      => 'KL',
                    'DeliverToState'     => 'KL',
                    'DeliverToPhone'     => '8505885570',
                    'DeliverToEmail'     => 'abc@abc.com',
                    'TotalWeight'        => 30,
                    'TotalVolume'        => 2,
                    'PaymentType'        => 'Prepaid',
                    'TotalPrice'         => 200,
                    'TotalPriceCurrency' => 'MYR',
                    'Parcels'            => [
                        [
                            'desc'   => 'iPhone 7',
                            'qty'    => 1,
                            'weight' => 10,
                            'width'  => '',
                            'height' => '',
                            'depth'  => '',
                        ],
                        [
                            'desc'   => 'iPhone 8',
                            'qty'    => 2,
                            'weight' => 20,
                            'width'  => '',
                            'height' => '',
                            'depth'  => '',
                        ],
                    ],
                    'SourceID'           => 'source',
                    'TimeStamp'          => 'time',
                    'Token'              => 'token',
                ],
            ],

        ];
    }

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();

        $this->timerMock = $this->createMock(TimerInterface::class);


        $this->endpoint = 'http://test-server/api/pickup-request';
        $this->token    = 'token';
        $this->fixTime  = 'time';
        $this->sourceId = 'source';


    }


}
