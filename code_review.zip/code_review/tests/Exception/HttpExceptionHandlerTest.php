<?php
declare(strict_types = 1);

namespace Tests\Tps\SNTModule\Exception;

use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;
use Tps\Contracts\Core\Http\Exception\HttpException;
use Tps\Contracts\Core\Processor\PackageCreationProcessorInterface;
use Tps\Contracts\Stubs\Core\Http\Exception\BadResponseStubException;
use Tps\Contracts\Stubs\Core\Http\Exception\ConnectStubException;
use Tps\Contracts\Stubs\Core\Http\Exception\RedirectRequestStubException;
use Tps\Contracts\Stubs\Core\Http\Exception\ServerStubException;
use Tps\SNTModule\Exception\HttpExceptionHandler;

/**
 * @covers \Tps\SNTModule\Exception\HttpExceptionHandler
 */
class HttpExceptionHandlerTest extends \PHPUnit_Framework_TestCase
{
    const EXCEPTION_MESSAGE = 'TEST_MESSAGE';

    const RETRIES = [0, 30, 60, 300];

    const DELAY_TIME = 60;

    /**
     * @var PackageCreationProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $processor;

    /**
     * {@inheritdoc}
     */
    public function setUp()
    {
        parent::setUp();

        $this->processor = $this->createMock(PackageCreationProcessorInterface::class);
    }

    /**
     * Data Provider for testing aborting exception handling
     *
     * @return array
     */
    public function providerHandleWithAbortingException()
    {
        return [
            [
                new RedirectRequestStubException(
                    $this->createMock(RequestInterface::class),
                    $this->createMock(ResponseInterface::class),
                    static::EXCEPTION_MESSAGE
                ),
            ],
            [
                new BadResponseStubException(
                    $this->createMock(RequestInterface::class),
                    $this->createMock(ResponseInterface::class),
                    static::EXCEPTION_MESSAGE
                ),
            ],
        ];
    }

    /**
     * @dataProvider providerHandleWithAbortingException
     *
     * @param HttpException $exception
     */
    public function testHandleWithAbortingException(HttpException $exception)
    {
        $this->processor
            ->expects(static::once())
            ->method('doReject')
            ->with($exception);
        $exceptionHandler = new HttpExceptionHandler(
            static::RETRIES
        );

        $exceptionHandler->handle($exception, $this->processor);
    }

    /**
     * @param HttpException $exception
     * @param string        $processorMethod
     * @param array         $retryConfig
     * @param int           $expectedDelay
     *
     * @dataProvider handleRetryProvider
     */
    public function testHandleRetry(
        HttpException $exception,
        string $processorMethod,
        array $retryConfig,
        int $expectedDelay
    ) {
        $this->processor
            ->expects(static::once())
            ->method($processorMethod)
            ->with($expectedDelay, $exception);
        $exceptionHandler = new HttpExceptionHandler(
            $retryConfig
        );

        $exceptionHandler->handle($exception, $this->processor);
    }

    /**
     * @return array
     */
    public function handleRetryProvider()
    {
        $expectedDelay           = 30;
        $expectedProcessorMethod = 'doRetry';

        return [
            'With ConnectException'    => [
                new ConnectStubException(
                    $this->createMock(RequestInterface::class),
                    self::EXCEPTION_MESSAGE
                ),
                $expectedProcessorMethod,
                self::RETRIES,
                $expectedDelay,
            ],
            'With ServerStubException' => [
                new ServerStubException(
                    $this->createMock(RequestInterface::class),
                    $this->createMock(ResponseInterface::class),
                    self::EXCEPTION_MESSAGE
                ),
                $expectedProcessorMethod,
                self::RETRIES,
                $expectedDelay,
            ],
        ];
    }

    /**
     * @param HttpException $exception
     * @param string        $processorMethod
     * @param array         $retries
     *
     * @dataProvider handleExceedRetryProvider
     */
    public function testHandleExceedRetryLimit(
        HttpException $exception,
        string $processorMethod,
        array $retries
    ) {
        $this->processor
            ->expects(static::once())
            ->method($processorMethod);
        $exceptionHandler = new HttpExceptionHandler(
            $retries
        );

        $exceptionHandler->handle($exception, $this->processor);
    }

    /**
     * @return array
     */
    public function handleExceedRetryProvider()
    {
        return [
            'With retries disabled' => [
                'Exception'             => new ConnectStubException(
                    $this->createMock(RequestInterface::class),
                    self::EXCEPTION_MESSAGE
                ),
                'Processor Method'      => 'doReject',
                'Retries Configuration' => [0],
            ],
        ];
    }
}
