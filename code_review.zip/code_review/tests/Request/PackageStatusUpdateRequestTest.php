<?php

declare(strict_types = 1);

namespace Tests\Tps\SNTModule\Request;

use PHPUnit\Framework\TestCase;
use Tps\SNTModule\Request\PackageStatusUpdateRequest;

/**
 * @covers \Tps\SNTModule\Request\PackageStatusUpdateRequest
 */
class PackageStatusUpdateRequestTest extends TestCase
{
    /**
     * @return array
     */
    public function validDataProvider(): array
    {
        return [
            [
                'trackingNumber'   => 'EM937726437MY',
                'tplStatus'        => 'D',
                'datetime'         => new \DateTime('-2 days'),
                'reasonCode'       => 'A2',
                'packageStatusLzd' => 'domestic_delivered',
                'reasonCodeLzd'    => 'Customer not at home',
            ],
            [
                'trackingNumber'   => 'EM937726437MY',
                'tplStatus'        => 'F1',
                'datetime'         => new \DateTime('-2 days'),
                'reasonCode'       => 'A1',
                'packageStatusLzd' => 'domestic_1st_attempt_failed',
                'reasonCodeLzd'    => 'Incomplete address',
            ],
        ];
    }

    /**
     * @dataProvider validDataProvider
     */
    public function testGetters($trackingNumber, $tplStatus, $datetime, $reasonCode, $packageStatusLzd, $reasonCodeLzd)
    {
        $request = new PackageStatusUpdateRequest(
            $trackingNumber,
            $tplStatus,
            $datetime,
            $reasonCode,
            $packageStatusLzd,
            $reasonCodeLzd
        );

        static::assertInstanceOf(PackageStatusUpdateRequest::class, $request);
        static::assertEquals($trackingNumber, $request->getTrackingNumber());
        static::assertEquals($packageStatusLzd, $request->getPackageStatus());
        static::assertEquals($tplStatus, $request->getTplStatus());
        static::assertEquals($reasonCode, $request->getTplReasonCode());
        static::assertEquals($reasonCodeLzd, $request->getReasonCode());
        static::assertEquals($datetime, $request->getDateTime());
        static::assertEmpty($request->getLocation());
        static::assertNull($request->getLatitudeLocation());
        static::assertNull($request->getLongitudeLocation());
    }
}
