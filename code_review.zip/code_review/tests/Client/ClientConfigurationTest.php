<?php
declare(strict_types = 1);

namespace Tests\Tps\SNTModule\Client;

use Tps\SNTModule\Client\ClientConfiguration;

/**
 * Class ClientConfiguration
 *
 * @coversDefaultClass Tps\SNTModule\Client\ClientConfiguration
 */
class ClientConfigurationTest extends \PHPUnit_Framework_TestCase
{
    public function setUp()
    {
        parent::setUp();
    }

    public function configurationDataProvider()
    {
        return [

            'allDataTest' => [
                'http://test.url.com',
                'token',
                '123123123',
                'sourceId',


            ],
        ];
    }

    /**
     *
     * @covers ::__construct()
     * @covers ::getPickupApiEndpoint
     * @covers ::getToken()
     * @covers ::getFixTime()
     * @covers ::getSourceId()
     *
     * @dataProvider configurationDataProvider
     *
     *
     *
     *
     *
     * @param string $pickupEndpoint
     * @param string $token
     * @param string $sourceId
     * @param string $fixTime
     *
     *
     *
     */
    public function testConstruct(
        string $pickupEndpoint,
        string $token,
        string $fixTime,
        string $sourceId


    ) {
        $clientConfig = new ClientConfiguration(
            $pickupEndpoint,
            $token,
            $fixTime,
            $sourceId
        );


        $this->assertEquals($pickupEndpoint, $clientConfig->getPickupApiEndpoint());
        $this->assertEquals($token, $clientConfig->getToken());
        $this->assertEquals($fixTime, $clientConfig->getFixTime());
        $this->assertEquals($sourceId, $clientConfig->getSourceId());

    }
}
