<?php

declare(strict_types = 1);

namespace Tests\Tps\SNTModule;

use Tps\Contracts\Core\Http\ClientInterface as HttpClientInterface;
use Tps\Contracts\Core\ModuleBuilderInterface;
use Tps\Contracts\Core\ModuleContainerInterface;
use Tps\SNTModule\Client\ClientConfiguration;
use Tps\SNTModule\RequestBuilder\PickupRequestBuilder;
use Tps\SNTModule\Handler\PackageCreationHandler;
use Tps\SNTModule\SNTModuleProvider;
use Tps\Contracts\Core\TimerInterface;
use Tps\SNTModule\Exception\HttpExceptionHandler;
use Tps\SNTModule\Handler\PackageStatusUpdateHandler;

/**
 * @property ModuleBuilderInterface|\PHPUnit_Framework_MockObject_MockObject   moduleBuilderMock
 * @property ModuleContainerInterface|\PHPUnit_Framework_MockObject_MockObject moduleContainerMock
 * @property SNTModuleProvider                                                 moduleProvider
 * @property ClientInterface|\PHPUnit_Framework_MockObject_MockObject          clientMock
 *
 * @covers \Tps\SNTModule\SNTModuleProvider
 */
class SNTModuleProviderTest extends \PHPUnit_Framework_TestCase
{
    /**
     * {@inheritdoc}
     */
    public function setUp()
    {
        parent::setUp();

        $this->moduleBuilderMock   = $this->createMock(ModuleBuilderInterface::class);
        $this->moduleContainerMock = $this->createMock(ModuleContainerInterface::class);
        $this->clientMock          = $this->createMock(HttpClientInterface::class);

        $this->moduleProvider = new SNTModuleProvider();
    }

    /**
     * @see LFlogisticsModule::registerHandlers
     */
    public function testRegisterHandlers()
    {
        $timerMock = $this->createMock(TimerInterface::class);
        $this->moduleContainerMock
            ->method('get')
            ->will(
                $this->returnValueMap(
                    [
                        [TimerInterface::class, [], $timerMock],
                        [HttpClientInterface::class, [], $this->clientMock],

                    ]
                )
            );

        $this->moduleBuilderMock->expects(static::once())
            ->method('registerPackageCreationHandler')
            ->with(
                static::callback(
                    function ($callable) {
                        $config = [
                            'pickup_endpoint'     => 'endpoint',
                            'token'               => 'token',
                            'fixed_timestamp'     => 'time',
                            'source_id'           => 'source',
                            'timezone'            => new \DateTimeZone('Asia/Kuala_Lumpur'),
                            'retry_config'        => [60, 120, 300]
                            ,
                            'status_mapping'      => [
                                'sample_status1' => 'status 1',
                                'sample_status2' => 'status 2',
                            ],
                            'reason_code_mapping' => [
                                'sample_reason1' => 'reason 1',
                                'sample_reason2' => 'reason 2',
                            ],
                        ];

                        $handler = $callable($this->moduleContainerMock, $config);
                        static::assertInstanceOf(PackageCreationHandler::class, $handler);


                        $pickupRequestBuilder = static::getObjectAttribute($handler, 'requestBuilder');
                        static::assertInstanceOf(PickupRequestBuilder::class, $pickupRequestBuilder);
                        static::assertAttributeEquals($config['timezone'], 'timezone', $pickupRequestBuilder);

                        $client = static::getObjectAttribute($handler, 'client');
                        static::assertSame($this->clientMock, $client);

                        $exceptionHandler = static::getObjectAttribute($handler, 'exceptionHandler');
                        static::assertInstanceOf(HttpExceptionHandler::class, $exceptionHandler);
                        static::assertAttributeEquals(
                            $config['retry_config'],
                            'retryConfig',
                            $exceptionHandler
                        );


                        return true;
                    }
                )
            )
            ->willReturnSelf();

        $this->moduleBuilderMock->expects(static::once())
            ->method('registerPackageStatusUpdateHandler')
            ->with(
                static::callback(
                    function ($callable) {

                        $config  = [
                            'status_mapping'      => [
                                'sample_status1' => 'status 1',
                                'sample_status2' => 'status 2',
                            ],
                            'reason_code_mapping' => [
                                'sample_reason1' => 'reason 1',
                                'sample_reason2' => 'reason 2',
                            ],
                        ];
                        $handler = $callable($this->moduleContainerMock, $config);
                        static::assertInstanceOf(
                            PackageStatusUpdateHandler::class,
                            $handler
                        );


                        return true;
                    }
                )
            )
            ->willReturnSelf();


        $this->moduleProvider->registerHandlers($this->moduleBuilderMock);
    }

    /**
     * @see SNTModule::getModuleName()
     */
    public function testGetModuleName()
    {
        Static::assertEquals('snt', $this->moduleProvider->getModuleName());
    }
}