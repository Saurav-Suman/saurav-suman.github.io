<?php
declare(strict_types = 1);

namespace Tests\Tps\SNTModule\Handler;

use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\StreamInterface;
use Tps\Contracts\Core\Http\ClientInterface;
use Tps\Contracts\Core\PackageCreationRequestInterface;
use Tps\Contracts\Core\Processor\Context\PackageCreationContextInterface;
use Tps\Contracts\Core\Processor\PackageCreationProcessorInterface;
use Tps\Contracts\Stubs\Core\Http\Exception\HttpStubException;
use Tps\SNTModule\Exception\HttpExceptionHandler;
use Tps\SNTModule\Exception\PickupRequestRejectedException;
use Tps\SNTModule\Handler\PackageCreationHandler;
use Tps\SNTModule\RequestBuilder\PickupRequestBuilder;

/**
 * @covers \Tps\SNTModule\Handler\PackageCreationHandler
 * @covers \Tps\SNTModule\Exception\PickupRequestRejectedException
 */
class PackageCreationHandlerTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @var ClientInterface |\PHPUnit_Framework_MockObject_MockObject
     */
    private $clientMock;

    /**
     * @var PickupRequestBuilder|\PHPUnit_Framework_MockObject_MockObject
     */
    private $builderMock;

    /**
     * @var PackageCreationHandler
     */
    private $handler;

    /**
     * @var HttpExceptionHandler|\PHPUnit_Framework_MockObject_MockObject
     */
    private $exceptionHandlerMock;

    /**
     * @var PackageCreationProcessorInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $processorMock;

    /**
     * @var \DateTimeZone
     */
    private $timezone;

    /**
     * @var PackageCreationContextInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $contextMock;

    /**
     * @var PackageCreationRequestInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $packageCreationReqMock;

    /**
     * @var PickupRequestBuilder|\PHPUnit_Framework_MockObject_MockObject
     */
    private $pickupRequestMock;

    /**
     * @var ResponseInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $responseMock;

    /**
     * @var StreamInterface|\PHPUnit_Framework_MockObject_MockObject
     */
    private $streamMock;

    /**
     * Test handle() in success case.
     */
    public function testHandle()
    {
        $this->contextMock->expects(static::once())
            ->method('getPackageCreationRequest')
            ->willReturn($this->packageCreationReqMock);

        $this->processorMock->expects(static::once())
            ->method('getContext')
            ->willReturn($this->contextMock);

        $this->builderMock->expects(static::once())
            ->method('buildRequest')
            ->with($this->packageCreationReqMock)
            ->willReturn($this->pickupRequestMock);

        $this->clientMock->expects(static::once())
            ->method('send')
            ->with($this->pickupRequestMock)
            ->willReturn($this->responseMock);

        $this->responseMock->expects(static::once())
            ->method('getBody')
            ->willReturn('{"message":"success","Code":200,"status_code":202,"errors":[["success"]]}');

        $this->processorMock->expects(static::once())
            ->method('doAccept');

        $this->exceptionHandlerMock->expects(static::never())
            ->method('handle');

        $this->handler->handle($this->processorMock);
    }

    /**
     * Test handle() in case of throwing HttpException.
     */
    public function testHandleInHttpException()
    {
        $this->contextMock->expects(static::once())
            ->method('getPackageCreationRequest')
            ->willReturn($this->packageCreationReqMock);

        $this->processorMock->expects(static::once())
            ->method('getContext')
            ->willReturn($this->contextMock);

        $this->builderMock->expects(static::once())
            ->method('buildRequest')
            ->with($this->packageCreationReqMock)
            ->willReturn($this->pickupRequestMock);

        /** @var \Exception $exceptionMock */
        $exceptionMock = $this->createMock(HttpStubException::class);

        $this->clientMock->expects(static::once())
            ->method('send')
            ->with($this->pickupRequestMock)
            ->willThrowException($exceptionMock);

        $this->processorMock->expects(static::never())
            ->method('doAccept');

        $this->exceptionHandlerMock->expects(static::once())
            ->method('handle')
            ->with($exceptionMock, $this->processorMock);

        $this->handler->handle($this->processorMock);
    }

    /**
     * Test handle() in case of throwing PickupRequestRejectedException.
     */
    public function testHandleInCasePickupRequestRejectedException()
    {
        $this->contextMock->expects(static::once())
            ->method('getPackageCreationRequest')
            ->willReturn($this->packageCreationReqMock);

        $this->processorMock->expects(static::once())
            ->method('getContext')
            ->willReturn($this->contextMock);

        $this->builderMock->expects(static::once())
            ->method('buildRequest')
            ->with($this->packageCreationReqMock)
            ->willReturn($this->pickupRequestMock);

        $this->clientMock->expects(static::once())
            ->method('send')
            ->with($this->pickupRequestMock)
            ->willReturn($this->responseMock);

        $this->responseMock->expects(static::once())
            ->method('getBody')
            ->willReturn(
                '{"message":"Unprocessable Entity","Code":422,"status_code":422,"errors":[["Bad Request Token.."]]}'
            );

        $this->processorMock->expects(static::never())
            ->method('doAccept');

        $this->exceptionHandlerMock->expects(static::once())
            ->method('handle')
            ->with(
                static::callback(
                    function ($exception) {
                        static::assertInstanceOf(
                            PickupRequestRejectedException::class,
                            $exception
                        );
                        static::assertEquals(
                            'Response is not returned success status.',
                            $exception->getMessage()
                        );
                        static::assertAttributeSame(
                            $this->pickupRequestMock,
                            'request',
                            $exception
                        );
                        static::assertAttributeSame($this->responseMock, 'response', $exception);
                        static::assertSame($this->pickupRequestMock, $exception->getRequest());
                        static::assertSame($this->responseMock, $exception->getResponse());

                        return true;
                    }
                ),
                $this->processorMock
            );

        $this->handler->handle($this->processorMock);
    }

    /**
     * Test handle() in case of throwing PickupRequestRejectedException.
     */
    public function testHandleInCasePickupRequestRejectedExceptionInvalidJson()
    {
        $this->contextMock->expects(static::once())
            ->method('getPackageCreationRequest')
            ->willReturn($this->packageCreationReqMock);

        $this->processorMock->expects(static::once())
            ->method('getContext')
            ->willReturn($this->contextMock);

        $this->builderMock->expects(static::once())
            ->method('buildRequest')
            ->with($this->packageCreationReqMock)
            ->willReturn($this->pickupRequestMock);

        $this->clientMock->expects(static::once())
            ->method('send')
            ->with($this->pickupRequestMock)
            ->willReturn($this->responseMock);

        $this->responseMock->expects(static::once())
            ->method('getBody')
            ->willReturn(
                '{"message":Unprocessable Entity","Code":300,"status_code":422,"errors":[["Bad Request Token.."]]}'
            );

        $this->processorMock->expects(static::never())
            ->method('doAccept');

        $this->exceptionHandlerMock->expects(static::once())
            ->method('handle')
            ->with(
                static::callback(
                    function ($exception) {
                        static::assertInstanceOf(
                            PickupRequestRejectedException::class,
                            $exception
                        );
                        static::assertEquals(
                            'Response is not in json format.',
                            $exception->getMessage()
                        );
                        static::assertAttributeSame(
                            $this->pickupRequestMock,
                            'request',
                            $exception
                        );
                        static::assertAttributeSame($this->responseMock, 'response', $exception);
                        static::assertSame($this->pickupRequestMock, $exception->getRequest());
                        static::assertSame($this->responseMock, $exception->getResponse());

                        return true;
                    }
                ),
                $this->processorMock
            );

        $this->handler->handle($this->processorMock);
    }

    /**
     * {@inheritdoc}
     */
    protected function setUp()
    {
        parent::setUp();
        $this->timezone = new \DateTimeZone('Asia/Kuala_Lumpur');

        $this->clientMock             = $this->createMock(ClientInterface::class);
        $this->builderMock            = $this->createMock(PickupRequestBuilder::class);
        $this->exceptionHandlerMock   = $this->createMock(HttpExceptionHandler::class);
        $this->processorMock          = $this->createMock(PackageCreationProcessorInterface::class);
        $this->contextMock            = $this->createMock(PackageCreationContextInterface::class);
        $this->packageCreationReqMock = $this->createMock(PackageCreationRequestInterface::class);
        $this->responseMock           = $this->createMock(ResponseInterface::class);
        $this->pickupRequestMock      = $this->createMock(RequestInterface::class);
        $this->streamMock             = $this->createMock(StreamInterface::class);

        $this->handler = new PackageCreationHandler($this->clientMock, $this->builderMock, $this->exceptionHandlerMock);
    }
}
