<?php

declare(strict_types = 1);

namespace Tests\Tps\SNTModule\Handler;

use Tps\Contracts\Core\Processor\PackageStatusUpdateProcessorInterface;
use Tps\SNTModule\Handler\PackageStatusUpdateHandler;
use Tps\SNTModule\Request\PackageStatusUpdateRequest;
use Tps\Contracts\Module\Exception\ValidationException;
use Tps\Contracts\Core\PackageStatusInterface as PSI;

/**
 * @covers \Tps\SNTModule\Handler\PackageStatusUpdateHandler
 */
class PackageStatusUpdateHandlerTest extends \PHPUnit_Framework_TestCase
{


    /**
     *
     * @var PackageStatusUpdateHandler
     */
    protected $handler;

    /**
     * @return array
     */
    public function createRequestObjectDataProvider(): array
    {
        return [
            'domestic_pickup/sign_in_success' => [
                'payload'  => [
                    'trackingno'       => 'EM937726437MY',
                    'failedreasonCode' => 'A1',
                    'statuscode'       => 'D',
                    'dateTime'         => '2017-10-10 12:00:00',
                ],
                'expected' => [
                    'tracking_number' => 'EM937726437MY',
                    'package_status'  => 'domestic_delivered',
                    'tplStatus'       => 'D',
                    'reasonCodeLzd'   => 'Incomplete address',
                    'reasonCode'      => 'A1',
                    'dateTime'        => \DateTime::createFromFormat(
                        'Y-m-d H:i:s',
                        '2017-10-10 12:00:00',
                        new \DateTimeZone('Asia/Kuala_Lumpur')
                    ),
                ],
            ],
            'domestic_1st_attempt_failed'     => [
                'payload'  => [
                    'trackingno'       => 'EM937726437MY',
                    'failedreasonCode' => 'A2',
                    'statuscode'       => 'F1',
                    'dateTime'         => '2017-10-15 12:00:00',
                ],
                'expected' => [
                    'tracking_number' => 'EM937726437MY',
                    'package_status'  => 'domestic_1st_attempt_failed',
                    'tplStatus'       => 'F1',
                    'reasonCodeLzd'   => 'Customer not at home',
                    'reasonCode'      => 'A2',
                    'dateTime'        => \DateTime::createFromFormat(
                        'Y-m-d H:i:s',
                        '2017-10-15 12:00:00',
                        new \DateTimeZone('Asia/Kuala_Lumpur')
                    ),
                ],
            ],

        ];
    }

    /**
     * @dataProvider createRequestObjectDataProvider
     *
     * @covers       \Tps\SNTModule\Handler\PackageStatusUpdateHandler::createRequestObject
     */
    public function testCreateRequestObjectSuccess($payload, $expected)
    {
        $request = $this->handler->createRequestObject($payload);
        static::assertInstanceOf(PackageStatusUpdateRequest::class, $request);
        static::assertEquals($expected['tracking_number'], $request->getTrackingNumber());
        static::assertEquals($expected['package_status'], $request->getPackageStatus());
        static::assertEquals($expected['tplStatus'], $request->getTplStatus());
        static::assertEquals($expected['reasonCodeLzd'], $request->getReasonCode());
        static::assertEquals($expected['reasonCode'], $request->getTplReasonCode());
        static::assertEquals($expected['dateTime'], $request->getDateTime());
    }

    /**
     * @return array
     */
    public function createRequestObjectExceptionDataProvider(): array
    {
        return [
            'connoteNo' => [
                'payload' => [
                    'trackingno'       => '',
                    'failedreasonCode' => 'A1',
                    'statuscode'       => 'EM004',
                    'dateTime'         => '2016-10-28 12:00:00',

                ],

                'message' => 'Missing "trackingno" parameter.',
            ],

            'eventCode'     => [
                'payload' => [
                    'trackingno'       => 'EM937726437MY',
                    'failedreasonCode' => 'A1',
                    'statuscode'       => '',
                    'dateTime'         => '2016-10-28 12:00:00',

                ],

                'message' => 'Missing "statuscode" parameter.',
            ],
            'Datetime'      => [
                'payload' => [
                    'trackingno'       => 'EM937726437MY',
                    'failedreasonCode' => 'A1',
                    'statuscode'       => 'N',
                    'dateTime'         => 'testdate',

                ],

                'message' => 'Value "testdate" of "dateTime" parameter is not in Y-m-d H:i:s format.',
            ],
            'DatetimeBlank' => [
                'payload' => [
                    'trackingno'       => 'EM937726437MY',
                    'failedreasonCode' => 'A1',
                    'statuscode'       => 'N',
                    'dateTime'         => '',

                ],

                'message' => 'Missing "dateTime" parameter.',
            ],
        ];
    }

    /**
     * @dataProvider createRequestObjectExceptionDataProvider
     *
     * @covers       \Tps\SNTModule\Handler\PackageStatusUpdateHandler::createRequestObject
     */
    public function testCreateRequestObjectExeception($payload, $message)
    {
        $this->expectException(ValidationException::class);
        $this->expectExceptionMessage($message);

        $request = $this->handler->createRequestObject($payload);
        static::assertInstanceOf(PackageStatusUpdateRequestInterface::class, $request);
    }

    /**
     * @see \Tps\SNTModule\Handler\PackageStatusUpdateHandler::handle
     */
    public function testHandle()
    {
        /** @var PackageStatusUpdateProcessorInterface|\PHPUnit_Framework_MockObject_MockObject $processorMock */
        $processorMock = $this->createMock(PackageStatusUpdateProcessorInterface::class);

        $processorMock->expects(static::once())
            ->method('doAccept');

        $this->handler->handle($processorMock);
    }

    protected function setUp()
    {
        parent::setUp();

        $status_mapping      = [
            'U'  => PSI::DOMESTIC_PICKUP_SIGN_IN_SUCCESS,
            'A'  => PSI::DOMESTIC_SC_SIGN_IN_SUCCESS,
            'O'  => PSI::DOMESTIC_OB_SUCCESS_IN_SORT_CENTER,
            'I'  => PSI::DOMESTIC_OUT_FOR_DELIVERY,
            'F1' => PSI::DOMESTIC_1ST_ATTEMPT_FAILED,
            'T1' => PSI::DOMESTIC_REDELIVERY,
            'D'  => PSI::DOMESTIC_DELIVERED,
            'F3' => PSI::DOMESTIC_DELIVERY_FAILED,
            'N'  => PSI::DOMESTIC_PACKAGE_RETURNED,
        ];
        $reason_code_mapping = [
            'A1' => 'Incomplete address',
            'A2' => 'Customer not at home',
        ];

        $this->handler = new PackageStatusUpdateHandler($status_mapping, $reason_code_mapping);
    }
}
